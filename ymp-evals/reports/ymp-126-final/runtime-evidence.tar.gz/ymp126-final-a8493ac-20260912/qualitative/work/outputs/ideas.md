# Workshop opening

Invite each participant to share their name and one small discovery with a nearby partner, offering everyone a comfortable chance to speak before the wider group discussion.

Place welcoming question cards on tables and let participants choose one to discuss together, then invite volunteers to share a common interest that emerged during their conversation.
